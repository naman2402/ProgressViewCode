//
//  Colours.swift
//  Steeper Demo
//
//  Created by Namaan.Agrawal on 11/08/21.
//

import Foundation

class Theme {
    
    var colors = Colors()
    
    private static var shareInstanse:Theme?
    
    static var current: Theme {
        // check for the current theme identifier and return the object.
        if shareInstanse == nil {
            shareInstanse = Theme()
        }
        return shareInstanse!
    }
    
    private init() { }
}

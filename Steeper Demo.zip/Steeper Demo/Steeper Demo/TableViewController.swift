//
//  TableViewController.swift
//  Steeper Demo
//
//  Created by Namaan.Agrawal on 09/08/21.
//

import Foundation
import StepIndicator
import UIKit

class TableView: UITableViewController
{
    let stepIndicatorView = StepIndicatorView()
    
    @IBOutlet weak var dueDate: UILabel!
    @IBOutlet weak var billPeriod: UILabel!
    @IBOutlet weak var paymentAmount: UILabel!
    @IBOutlet weak var paymentMethod: UILabel!
    @IBOutlet weak var progressView: UIProgressView!
    override  func viewDidLoad() {
        
        self.stepIndicatorView.frame = CGRect(x: 0, y: 50, width: 280, height: 100)
        self.view.addSubview(self.stepIndicatorView)
        
        self.stepIndicatorView.numberOfSteps = 2
        self.stepIndicatorView.currentStep = 0
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("The selected section: \(indexPath.section)")
    }
    
    
}



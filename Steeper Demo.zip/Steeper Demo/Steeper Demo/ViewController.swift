//
//  ViewController.swift
//  Steeper Demo
//
//  Created by Namaan.Agrawal on 06/08/21.
//
import UIKit

class ViewController: UIViewController
{
    @IBOutlet var tableView: UITableView!
    
    
    let data = ["Account Number", "Invoice ID", "Due Date", "Amount"]
    override func viewDidLoad() {
        super.viewDidLoad()
    
        tableView.delegate = self
        tableView.dataSource = self
        
        let header = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 300))
        let footer = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 300))
        footer.backgroundColor = .orange
        header.backgroundColor = .green
       // header.textLabel?.text = "Header for Stepper"
        
        tableView.tableHeaderView = header
        tableView.tableFooterView = footer
    }
    
}

extension ViewController: UITableViewDelegate{
    
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
}

extension ViewController: UITableViewDataSource {
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10.0
    }
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = data[indexPath.row]
        cell.backgroundColor = .lightGray
        return cell
    }
}

//
//  Utility.swift
//  Steeper Demo
//
//  Created by Namaan.Agrawal on 12/08/21.
//


import Foundation
import AVKit
import CoreTelephony
import MapKit
import MobileCoreServices


typealias CompletionHandlerForAlert = ((_ index:Int) -> Void)?

class Utility: NSObject {
    
    class func isIphone() -> Bool {
        return UIDevice.current.userInterfaceIdiom == .phone
    }
    
    class func isIpad() -> Bool {
        return UIDevice.current.userInterfaceIdiom == .pad
    }
    
    class func showSmartAlertWithTitle(_ title:String = "", _ message:String = "", buttonsTitle:[String] = [AppAlertMessage.ok.buttonTitle()], inController: UIViewController?, handler: CompletionHandlerForAlert) {
        
        
        DispatchQueue.main.async {
            let vc = SCMCustomAlertVC.instantiate(fromAppStoryboard: .Common)
            
            vc.view.backgroundColor = UIColor(white: 0.0, alpha: 0.50)
            vc.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
            vc.providesPresentationContextTransitionStyle = true
            vc.definesPresentationContext = true
            vc.configureOkButton(withTitle:title.isReallyEmpty ? AppAlertMessage.message.string() : title , andMessage: message, andButtonTitle: buttonsTitle.first ?? AppAlertMessage.ok.buttonTitle(), callOkButtonClosure: {
                vc.view.alpha = 0
                DispatchQueue.main.async {
                    UIView.animate(withDuration: 0.2, animations: {
                        vc.dismiss(animated: true, completion: {
                            if let value = handler {
                                value(0)
                            }
                            vc.view.alpha = 1
                        })
                    })
                }
            })
            
            if buttonsTitle.count == 2 {
                vc.configureCancelButton(withTitle: buttonsTitle.last ?? AppAlertMessage.cancel.buttonTitle()) {
                    vc.view.alpha = 1
                    
                    DispatchQueue.main.async {
                        UIView.animate(withDuration: 0.2, animations: {
                            
                            vc.dismiss(animated: true, completion: {
                                if let value = handler {
                                    value(1)
                                }
                                vc.view.alpha = 0
                            })
                        })
                    }
                }
            }
            
            DispatchQueue.main.async {
                vc.view.alpha = 0
                let window = UIApplication.shared.windows.filter {$0.isKeyWindow}.first
                window?.rootViewController?.present(vc, animated: true,completion: {
                    UIView.animate(withDuration: 0.2, animations: {
                        vc.view.alpha = 1.0
                    })
                })
            }
            
        }
        
        
    }
    
    static func isDeviceRooted() -> Bool {
        if TARGET_IPHONE_SIMULATOR != 1
        {
            // Check 1 : existence of files that are common for jailbroken devices
            if FileManager.default.fileExists(atPath: "/Applications/Cydia.app")
                || FileManager.default.fileExists(atPath: "/Library/MobileSubstrate/MobileSubstrate.dylib")
                || FileManager.default.fileExists(atPath: "/bin/bash")
                || FileManager.default.fileExists(atPath: "/usr/sbin/sshd")
                || FileManager.default.fileExists(atPath: "/etc/apt")
                || FileManager.default.fileExists(atPath: "/private/var/lib/apt/")
                || UIApplication.shared.canOpenURL(URL(string:"cydia://package/com.example.package")!)
            {
                return true
            }
            // Check 2 : Reading and writing in system directories (sandbox violation)
            let stringToWrite = "Jailbreak Test"
            do
            {
                try stringToWrite.write(toFile:"/private/JailbreakTest.txt", atomically:true, encoding:String.Encoding.utf8)
                //Device is jailbroken
                return true
            }catch
            {
                return false
            }
        }else
        {
            return false
        }
    }
    
    class func getIPAddress() -> String {
        var addresses = [String]()
        
        // Get list of all interfaces on the local machine:
        var ifaddr : UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddr) == 0 else { return "" }
        guard let firstAddr = ifaddr else { return "" }
        
        // For each interface ...
        for ptr in sequence(first: firstAddr, next: { $0.pointee.ifa_next }) {
            let flags = Int32(ptr.pointee.ifa_flags)
            var addr = ptr.pointee.ifa_addr.pointee
            
            // Check for running IPv4, IPv6 interfaces. Skip the loopback interface.
            if (flags & (IFF_UP|IFF_RUNNING|IFF_LOOPBACK)) == (IFF_UP|IFF_RUNNING) {
                //                if addr.sa_family == UInt8(AF_INET) || addr.sa_family == UInt8(AF_INET6) {
                if addr.sa_family == UInt8(AF_INET) {
                    
                    // Convert interface address to a human readable string:
                    var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                    if (getnameinfo(&addr, socklen_t(addr.sa_len), &hostname, socklen_t(hostname.count),
                                    nil, socklen_t(0), NI_NUMERICHOST) == 0) {
                        let address = String(cString: hostname)
                        addresses.append(address)
                    }
                }
            }
        }
        
        freeifaddrs(ifaddr)
        return addresses.first ?? ""
//        return "192.168.1.101"
    }
    
    class func customAttributes() -> JSONDictionary {
        return [
            // APIKeys.ip: Utility.getIPAddress(),
            APIKeys.client: AppConstants.AppInfo.client,
            APIKeys.version: AppConstants.AppInfo.version,
            APIKeys.deviceType: AppConstants.AppInfo.deviceType,
            APIKeys.languageCode :  AppSettings.shared.languageCode.rawValue
        ]
    }
    
    class func getErrorMessageParsing(key: String) -> SCMError {
        return SCMError(message: key)
    }
    
    class func readDataFromCSV(fileName: String, fileType: String) -> [[String: String]] {
        guard let filepath = Bundle.main.path(forResource: fileName, ofType: fileType) else {
            return [["":""]]
        }
        do {
            let csv = try CSVParser(filePath: filepath)
            let jsonStr = try csv.toJSON()
            return jsonStr
            
        } catch {
            print("File Read Error for file \(filepath)")
            return [["":""]]
        }
    }
    
    class func getVersion() -> String {
        return Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? ""
    }
    
    class func getBuildNumber() -> String {
        return Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? ""
    }
    
    class func createDownloadEncryptedPathForImage(attachmentName:String, path:String, url:String)->String {
        var attachmentPath: String? = ""
        let date = Date()
        let formatter = DateFormatter()
        formatter.timeZone = TimeZone(abbreviation: "GMT")
        formatter.dateFormat = "yyyyMMddHH"
        let result = formatter.string(from: date)
        
        //&LoginToken=\(User.shared.loginToken)
        let queryStr :String? = "imagename=\(attachmentName)&Path=\(path)&RequestTime=\(result)&UserId=\(User.shared.userID)&LoginToken=\(User.shared.loginToken)"
        print(queryStr)
        let encString = queryStr?.encriptedString()
        attachmentPath = "\(url)?q=\(encString ?? "")"
        return attachmentPath!
        
    }
    class func RandomString64Bit(length: Int) -> String {
        
        let letters : NSString = "abcdef0123456789"
        let len = UInt64(letters.length)
        
        var randomString = ""
        
       
        for _ in 0 ..< length {
            let rand = UInt64(arc4random_uniform(UInt32(len)))
            var nextChar = letters.character(at: Int(rand))
            randomString += NSString(characters: &nextChar, length: 1) as String
        }
        
        return randomString
    }
    class func randomString(length: Int) -> String {
        
        let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        let len = UInt32(letters.length)
        
        var randomString = ""
        
        for _ in 0 ..< length {
            let rand = arc4random_uniform(len)
            var nextChar = letters.character(at: Int(rand))
            randomString += NSString(characters: &nextChar, length: 1) as String
        }
        
        return randomString
    }
    
    class func generateMediaFileNameWithFileExtension(fileExtension:String,mediaType:mediaTypeID)-> String{
        let formattedDateValue =  Date().stringWithFormat(format: "ddMMyy")
        var fileName: String = ""
        switch mediaType{
            case .kImage:
                fileName = "img_\(Utility.randomString(length : 5))_\(formattedDateValue).\(fileExtension)"
            case .kVideo:
                fileName = "mov_\(Utility.randomString(length : 5))_\(formattedDateValue).mov"
            default:
                break
        }
        return fileName
    }
    
    class func isFileSizeInvalid(data:Data)->Bool{
        var isFileSizeInvalid = false
        if data.count/1048576 > 5{
            isFileSizeInvalid = true
            
        }
        return isFileSizeInvalid
    }
    class func isFileSizeInvalidCount(count: Int)->Bool{
        var isFileSizeInvalid = false
        if count/1048576 > 5{
            isFileSizeInvalid = true
            
        }
        return isFileSizeInvalid
    }
    //MARK: getFileNameAndExtension
    class func getFileNameAndExtension(media: [UIImagePickerController.InfoKey: Any], handler:@escaping (_ fileName: String, _ fileExtension: String, _ mediaType: mediaTypeID, _ videoUrl: String) -> Void) {
        var mediaType: mediaTypeID? = .kImage
        var mediaFileName:String? = ""
        var mediaFileExtension: String? = ""
        let mediaVideoValue: String? = ""
        
        
        if media[.mediaType] as? String == "public.movie" {
            mediaType = .kVideo
            mediaFileExtension = "mov"
        } else if media[.mediaType] as? String == "public.image" {
            mediaType = .kImage
            mediaFileExtension = "jpg"
        }
        if  mediaType == .kImage {
            if let assetPath = media[UIImagePickerController.InfoKey.imageURL] as? NSURL {
                if (assetPath.absoluteString?.lowercased().hasSuffix("jpg"))!{
                    mediaFileExtension = "jpg"
                }
                else if (assetPath.absoluteString?.lowercased().hasSuffix("jpeg"))! {
                    mediaFileExtension = "jpeg"
                }
                else if (assetPath.absoluteString?.lowercased().hasSuffix("png"))! {
                    mediaFileExtension = "png"
                }
                else if (assetPath.absoluteString?.lowercased().hasSuffix("gif"))! {
                    mediaFileExtension = "gif"
                }else if (assetPath.absoluteString?.lowercased().hasSuffix("bmp"))! {
                    mediaFileExtension = "bmp"
                }
                else {
                    mediaFileExtension = "Unknown"
                }
            }
        } else {
            if let assetPath = media[UIImagePickerController.InfoKey.mediaURL] as? NSURL {
                if (assetPath.absoluteString?.hasSuffix("mp4"))!{
                    mediaFileExtension = "mp4"
                }
                else {
                    mediaFileExtension = "mov"
                }
            }
        }
        //mediaFileExtension = mediaType == .kImage ? "jpg" : "mov"
        mediaFileName = self.fetchMediaFileNameviaExtension(mediaTypeValue: mediaType!, mediaExtension: mediaFileExtension!)
        handler(mediaFileName!,mediaFileExtension!,mediaType!,mediaVideoValue ?? "")
    }
    
    class func fetchMediaFileNameviaExtension(mediaTypeValue:mediaTypeID,mediaExtension:String)->String{
        var fileName: String?
        if User.shared.isLoggedIn() {
            fileName = generateMediaFileNameWithCustomerIDAndFileExtension(fileExtension:mediaExtension)
        } else {
            fileName = generateMediaFileNameWithFileExtension(fileExtension:mediaExtension,mediaType:mediaTypeValue)
        }
        return fileName!
    }
    
    class func generateMediaFileNameWithCustomerIDAndFileExtension(fileExtension:String)->String{
        let formattedDateValue =  Date().stringWithFormat(format: "ddMMyy")
        let randomID = arc4random() % 100
        let randomValue = "\(Utility.randomString(length : 3))\(randomID)"
        let fileName = "\(User.shared.userID)_\(randomValue)_\(formattedDateValue).\(fileExtension)"
        return fileName
    }
    
    class func fetchImageandMediaData(media: [UIImagePickerController.InfoKey: Any], handler: @escaping (_ data:Data, _ image: UIImage, _ size: Int) -> Void) {
        
        var mediaType: mediaTypeID = .kImage
        
        if media[.mediaType] as? String == "public.movie" {
            mediaType = .kVideo
        } else if media[.mediaType] as? String == "public.image" {
            mediaType = .kImage
        }
        var actualFileSize = 0
        if let mediaUrl =  media[.imageURL] as? URL{
            let asset = AVURLAsset.init(url: mediaUrl)
            do {
                try actualFileSize = Data.init(contentsOf: asset.url).count
            }catch{
                print(error)
            }
            
        }
        switch mediaType {
            case .kVideo:
                if let assetUrl = media[.mediaURL] as? URL{
                    let asset = AVURLAsset.init(url: assetUrl)
                    do {
                        let videoData = try Data(contentsOf: asset.url)
                        handler(videoData, SCMFont.imageWithType(type:.videoIcon, color: Theme.current.colors.primary, size: 15.0),actualFileSize)
                    } catch {
                        print(error)
                    }
                }
                
            case .kImage:
                
                //To get Edited image from image picker view
                var image = media[.originalImage]
                
                if let img = media[.editedImage] as? UIImage {
                    image =  img
                } else if let img = media[.originalImage] as? UIImage {
                    image =  img
                }
                
                
                if let assetPath = media[UIImagePickerController.InfoKey.imageURL] as? NSURL {
                    if (assetPath.absoluteString?.uppercased().hasSuffix("PNG"))! {
                        let mediaData = (image as! UIImage).pngData()
                        handler(mediaData!,image as! UIImage,actualFileSize)
                    }
                    else {
                        let mediaData = (image as! UIImage).jpegData(compressionQuality: 1.0)
                        handler(mediaData!,image as! UIImage,actualFileSize)
                    }
                }
                
                
            default:
                break
        }
    }
    class func fixOrientation(img: UIImage) -> UIImage {
        if (img.imageOrientation == .up) {
            return img
        }
        
        UIGraphicsBeginImageContextWithOptions(img.size, false, img.scale)
        let rect = CGRect(x: 0, y: 0, width: img.size.width, height: img.size.height)
        img.draw(in: rect)
        
        let normalizedImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        return normalizedImage
    }
    
    
    //: Make button as hyperlink with colour text and font.
    class func hyperLinkButton(textStr: String, font: UIFont, color: UIColor) -> NSMutableAttributedString {
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: color,
            .underlineStyle: NSUnderlineStyle.single.rawValue]
        return  NSMutableAttributedString(string: textStr,
                                          attributes: attributes)
    }
    
    
    class func stringValue(_ value:Any?) -> String {
        if value is String {
            return (value as? String) ?? ""
        } else if value is Contact {
            return (value as? Contact)?.number ?? ""
        }
        return ""
    }
    
    class func boolValue(_ value:Any?) -> Bool {
        (value as? Bool) ?? false
    }
    
    class func intValue(_ value:Any?) -> Int {
        (value as? Int) ?? 0
    }
    
    class func floatValue(_ value:Any?) -> Float {
        (value as? Float) ?? 0.0
    }
    
    class func transactionDisclaimer(fees: String, max: String)->String {
        var final = ""
        
        let processingFeeStr = "ML_Billing_Span_drIsProcessingFee".controlString().replacingOccurrences(of: "$XXXXX", with: fees.prependDoller())
        let maxLimitStr = "ML_Billing_Span_drMaxbilling".controlString().replacingOccurrences(of: "$XXXXX", with: max.prependDoller())
        
        final = processingFeeStr + " " + maxLimitStr
        
        return final
    }
    
    /**
     *
     * Use this method to add K or M for large numbers and to add configurable number of decimals
     *
     **/
    func abbreviateNumber(_ num : String, isCurrency: Bool = false) -> String {
        
        var numWithoutDecimals = num
        if let indexOfDot = num.firstIndex(of: Character(".")) {
            let indexBeforeDot = num.index(before: indexOfDot)
            numWithoutDecimals = num.substringTo(indexIn: indexBeforeDot.encodedOffset)
            //                 numWithoutDecimals = num.substringTo(indexIn: indexBeforeDot.utf16Offset(in: num))
            
        }
        
        let numWithoutComma = (numWithoutDecimals as NSString).replacingOccurrences(of: ",", with: "")
        
        if numWithoutComma.count > 8 {
            //remove chars after . along with . and pass remaining chars to method
            return self.formatWithM(numWithoutComma, isCurrency: isCurrency)
        } else if numWithoutComma.count > 5 {
            //remove chars after . along with . and pass remaining chars to method
            return self.formatWithK(numWithoutComma, isCurrency: isCurrency)
        }
        
        //12345.12 - //12345.1200
        return self.appendZeroAfterDecimal(num, isCurrency: isCurrency)
        //        return num
    }
    
    func formatWithK(_ num: String, isCurrency: Bool) -> String {
        //num is greater than 5 digits and without comma
        //remove last 1 char; and then append . at 3rd last position
        
        //123456 – 123.456 K
        //1234567 – 1234.567 K
        //12345678 – 12345.678 K
        
        let floatNum = num.floatValue()
        if floatNum != 0 {
            let numInM = floatNum / Float(1000)
            var format = "%.\(AppSettings.shared.decimalCount)f"
            if isCurrency {
                format = "%.\(AppSettings.shared.currencyDecimalCount)f"
            }
            let strNumInM = String(format: format, numInM)
            
            let arr = (strNumInM as NSString).components(separatedBy: ".")
            let strFirst = arr[0]
            var strLast = ""
            if arr.count > 1 {
                strLast = arr[1]
            }
            
            let intOfFirst = strFirst.intValue()
            
            let firstPartWithComma = self.addCommaInNumber(num: intOfFirst)
            
            var numToReturn = firstPartWithComma
            if strLast.count > 0 {
                numToReturn = firstPartWithComma + "." + strLast
            }
            
            return numToReturn + "K"
        }
        
        return num
    }
    
    func formatWithM(_ num : String, isCurrency: Bool) -> String {
        //num is greater than 8 digits and without comma
        //remove last 4 chars; and then append . at 3rd last position
        
        // 123456789 – 123.456789 M
        // 1234567890 - 1234.567890 M
        
        let floatNum = num.floatValue()
        if floatNum != 0 {
            let numInM = floatNum / Float(1000000)
            var format = "%.\(AppSettings.shared.decimalCount)f"
            if isCurrency {
                format = "%.\(AppSettings.shared.currencyDecimalCount)f"
            }
            let strNumInM = String(format: format, numInM)
            
            let arr = (strNumInM as NSString).components(separatedBy: ".")
            let strFirst = arr[0]
            var strLast = ""
            if arr.count > 1 {
                strLast = arr[1]
            }
            
            let intOfFirst = strFirst.intValue()
            
            let firstPartWithComma = self.addCommaInNumber(num: intOfFirst)
            
            var numToReturn = firstPartWithComma
            if strLast.count > 0 {
                numToReturn = firstPartWithComma + "." + strLast
            }
            
            return numToReturn + "M"
        }
        
        return num
    }
    
    /**
     *
     * Use this method to add configurable number of decimals in a number along with comma
     *
     **/
    func appendZeroAfterDecimal(_ num: String, isCurrency: Bool = false) -> String {
        var numToReturn = num
        
        //12345.12 - //12345.1200
        //12345.12 - //12345.1200
        
        let numWithoutComma = (num as NSString).replacingOccurrences(of: ",", with: "")
        
        let numFloat = numWithoutComma.floatValue()
        
        var format = "%.\(AppSettings.shared.decimalCount)f"
        if isCurrency {
            format = "%.\(AppSettings.shared.currencyDecimalCount)f"
        }
        let strWithCorrectNumberOfDecimals = String(format: format, numFloat)
        
        let arr = (strWithCorrectNumberOfDecimals as NSString).components(separatedBy: ".")
        let strFirst = arr[0]
        var strLast = ""
        if arr.count > 1 {
            strLast = arr[1]
        }
        
        let intOfFirst = strFirst.intValue()
        
        let firstPartWithComma = self.addCommaInNumber(num: intOfFirst)
        
        if strLast.count > 0 {
            numToReturn = firstPartWithComma + "." + strLast
        } else {
            numToReturn = firstPartWithComma
        }
        
        return numToReturn
    }
    
    func addCommaInNumber(num: Int) -> String {
        
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = NumberFormatter.Style.decimal
        let formattedNumber = numberFormatter.string(from: NSNumber(value: num))
        
        return formattedNumber ?? String(format: "%d", num)
    }
    //Checks if the phone number entered is valid
    class func isValidPhone(_ value: String) -> Bool {
        let value = value.convertedDigitsToLocale(Locale(identifier: "EN"))
        if value.count != TextInputType.mobileNumber.maxLength {
            return false
        }
        let phoneRegex = InputValidationPattern.mobileNumber.pattern
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        let result =  phoneTest.evaluate(with: value)
        
        if result {
            var mySubstring = String(value.prefix(3))
            if value.contains("(") {
                let str = String(value.prefix(5)).replacingOccurrences(of: "(", with: "")
                mySubstring = str.replacingOccurrences(of: ")", with: "")
            }
            if mySubstring.intValue() > 100 {
                return true
            }
            else{
                return false
            }
        }
        return result
        
    }
    
    // calculate Center
    class func calculateCenter(coordinates : [CLLocationCoordinate2D], n : Int) -> CLLocationCoordinate2D
    {
        // calculate center of polygon
        var maxLat:Float = -1000.0
        var maxLong:Float = -1000.0
        var minLat = MAXFLOAT
        var minLong = MAXFLOAT
        
        for i in 0..<n {
            let location = coordinates[i]
            if  Float(location.latitude) < minLat
            {
                minLat = Float(location.latitude)
            }
            if  Float(location.longitude) < minLong {
                minLong =  Float(location.longitude)
            }
            if Float(location.latitude) > maxLat {
                maxLat = Float(location.latitude)
            }
            
            if Float(location.longitude) > maxLong {
                maxLong = Float(location.longitude)
            }
        }
        let center = CLLocationCoordinate2DMake(CLLocationDegrees((maxLat + minLat) * 0.5), CLLocationDegrees((maxLong + minLong) * 0.5))
        return center
    }
    
    /// Calling a number
    ///
    /// - Parameters:
    ///   - phNumber: Number in String
    ///   - callFromViewController: reference of controllers, class where we have triggered this method.
    
    func callPhoneMethod(phNumber:String, callFromViewController:UIViewController) {
        
        guard let number = URL(string: "tel://" + phNumber) else { return }
        
        
        if UIApplication.shared.canOpenURL(number){
            // Device supports phone calls, lets confirm it can place one right now
            
            let netInfo:CTTelephonyNetworkInfo? = CTTelephonyNetworkInfo()
            let carrier:CTCarrier? = netInfo?.subscriberCellularProvider
            
            if (carrier?.mobileNetworkCode == nil) || carrier?.mobileNetworkCode == "65535"{
                
                // Device cannot place a call at this time.  SIM might be removed.
                //  AlertManager.showAlert(title: kCommonAlertMsg, message: String(format:"%@ %@",device_not_support_call_feature,Utility.formateNumberWithHyphen(phNumber)), buttons: [kCommonOk], inController: callFromViewController, handler: { (alertAction, indexInt) in
                //Nothing to do.
                // })
            }
            else{
                // Device can place a phone call
                if phNumber.count > 0 {
                    if #available(iOS 10.0, *) {
                        UIApplication.shared.open(number)
                    } else {
                        UIApplication.shared.openURL(number)
                    }
                }
            }
        }
        else{
            
            
            //            AlertManager.showAlert(title: kCommonAlertMsg, message: String(format:"%@ %@",device_not_support_call_feature,Utility.formateNumberWithHyphen(phNumber)), buttons: [kCommonOk], inController: callFromViewController, handler: { (alertAction, indexInt) in
            //                //Nothing to do.
            //            })
        }
    }
    
    
    static func createCSVX(from recArray:[Dictionary<String, Any>], handler: @escaping ((_ filePath: URL?) -> Void)) {
        
        // No need for string interpolation ("\("Time"),\("Force")\n"), just say what you want:
        let heading = "FirstName, MiddleName, LastName, PrimaryEmailAddress, PrimaryPhoneNumber, PrimaryPhoneType, AlternateEmailAddress, AlternatePhoneNumber, AlternatePhoneType, MailingAddress, Username\n"
        
        //        , Property
        
        // For every element in recArray, extract the values associated with 'T' and 'F' as a comma-separated string.
        // Force-unwrap (the '!') to get a concrete value (or crash) rather than an optional
        //let rows = recArray.map { "\($0["T"]!),\($0["F"]!)" }
        let rows = recArray.map{"\($0.scmStringForKey(key: "FirstName")),\($0.scmStringForKey(key: "MiddleName")),\($0.scmStringForKey(key: "LastName")),\($0.scmStringForKey(key: "PrimaryEmailAddress")),\($0.scmStringForKey(key: "PrimaryPhoneNumber")),\($0.scmStringForKey(key: "PrimaryPhoneType")),\($0.scmStringForKey(key: "AlternateEmailAddress")),\($0.scmStringForKey(key: "AlternatePhoneNumber")),\($0.scmStringForKey(key: "AlternatePhoneType")),\($0.scmStringForKeyCSV(key: "MailingAddress")),\($0.scmStringForKey(key: "UserName"))"}
        
        //        ,\($0.scmStringForKeyCSV(key: "Property"))
        
        // Turn all of the rows into one big string
        print(rows)
        let csvString = heading + rows.joined(separator: "\n")
        
        do {
            
            var path = try FileManager.default.url(for: .documentDirectory,
                                                   in: .allDomainsMask,
                                                   appropriateFor: nil,
                                                   create: false)
            path.appendPathExtension("CSV")
            let filename = "PersonalInformation\(User.shared.userID)"
            let fileURL = path.appendingPathComponent(filename)
            try csvString.write(to: fileURL, atomically: true , encoding: .utf8)
            handler(fileURL)
        } catch {
            handler(nil)
            print("error creating file")
        }
        //FirstName, MiddleName, LastName, PrimaryEmailAddress, PrimaryPhoneNumber, PrimaryPhoneType, AlternateEmailAddress, AlternatePhoneNumber, AlternatePhoneType, MailingAddress, Username, Property
    }
    
    static func createCSVA(from recArray:[Dictionary<String, Any>], handler: @escaping ((_ filePath: URL?) -> Void)) {
        
        // No need for string interpolation ("\("Time"),\("Force")\n"), just say what you want:
        let heading = ""
        
        // For every element in recArray, extract the values associated with 'T' and 'F' as a comma-separated string.
        // Force-unwrap (the '!') to get a concrete value (or crash) rather than an optional
        
        //let rows = recArray.map { "\($0["T"]!),\($0["F"]!)" }
        
        
        let notiType = recArray.map{"\($0.scmStringForKey(key: "NotificationType"))"}
        
        let uniquenotiType = Array(Set(notiType))
        
        var rows = [String]()
        
        for item in uniquenotiType{
            rows.append("\(item)")
            
            let arr = recArray.filter{"\($0.scmStringForKey(key: "NotificationType"))" == item}
            for val in arr{
                rows.append("\(val.scmStringForKey(key: "EmailORPhone"))")
            }
        }
        
        //        let rows = recArray.map{"\($0.scmStringForKey(key: "NotificationType"))\n\($0.scmStringForKey(key: "EmailORPhone"))\n"}
        
        
        // Turn all of the rows into one big string
        print(rows)
        let csvString = heading + rows.joined(separator: "\n")
        
        do {
            
            let path = try FileManager.default.url(for: .documentDirectory,
                                                   in: .allDomainsMask,
                                                   appropriateFor: nil,
                                                   create: false)
            
            let fileURL = path.appendingPathComponent("AccountNotification.csv")
            try csvString.write(to: fileURL, atomically: true , encoding: .utf8)
            handler(fileURL)
        } catch {
            handler(nil)
            print("error creating file")
        }
        //AccountNotificationType, EmailORPhone, Notify
    }
    
    class func downloadBillPDF(url:URL, encKey: String,handler:@escaping ([String: URL])-> Void) {
        var request = URLRequest(url: url)
        request.addValue(encKey, forHTTPHeaderField: "AUTH_TOKEN")
        request.addValue(String(format: "%@:%@", AppSettings.shared.preLoginTokenDetail.tokenKey, AppSettings.shared.preLoginTokenDetail.tokenID), forHTTPHeaderField: "ACCESS_TOKEN")
        let config = URLSessionConfiguration.default
        let session =  URLSession(configuration: config)
        AppGlobals.startLoading()
        let task = session.dataTask(with: request, completionHandler: {(data, response, error) in
            if error == nil {
                if let pdfData = data {
                    DispatchQueue.main.async {
                        AppGlobals.stopLoading()
                        FileManager.default.clearTmpDirectory()
                        let directory = NSTemporaryDirectory()
                        let fileName = NSUUID().uuidString + ".pdf"
                        
                        // This returns a URL? even though it is an NSURL class method
                        let fullURL = NSURL.fileURL(withPathComponents: [directory, fileName]) ?? NSURL.init(string: "Empty")! as URL
                        // Create URL from file system string:
                        do {
                            try pdfData.write(to: fullURL)
                        }
                        catch {
                            print("Error: \(error)")
                        }
                        handler(["FileURL": fullURL])
                    }
                }
            }
        })
        task.resume()
    }
}

extension URL {
    func fileName() -> String {
        return self.deletingPathExtension().lastPathComponent
    }
    
    func fileExtension() -> String {
        return self.pathExtension
    }
    func fileNameWithExtension() -> String {
        return self.lastPathComponent
    }
}


extension FileManager {
    func clearTmpDirectory() {
        do {
            let tmpDirectory = try contentsOfDirectory(atPath: NSTemporaryDirectory())
            try tmpDirectory.forEach {[unowned self] file in
                let path = String.init(format: "%@%@", NSTemporaryDirectory(), file)
                try self.removeItem(atPath: path)
            }
        } catch {
            print(error)
        }
    }
}

extension String {
    private static let formatter = NumberFormatter()

    func clippingCharacters(in characterSet: CharacterSet) -> String {
        components(separatedBy: characterSet).joined()
    }

    func convertedDigitsToLocale(_ locale: Locale = .current) -> String {
        let digits = Set(clippingCharacters(in: CharacterSet.decimalDigits.inverted))
        guard !digits.isEmpty else { return self }

        Self.formatter.locale = locale

        let maps: [(original: String, converted: String)] = digits.map {
            let original = String($0)
            let digit = Self.formatter.number(from: original)!
            let localized = Self.formatter.string(from: digit)!
            return (original, localized)
        }

        return maps.reduce(self) { converted, map in
            converted.replacingOccurrences(of: map.original, with: map.converted)
        }
    }
}


struct RandomNumberGeneratorWithSeed: RandomNumberGenerator {
    init(seed: Int) {
        // Set the random seed
        srand48(seed)
    }
    
    func next() -> UInt64 {
        // drand48() returns a Double, transform to UInt64
        return withUnsafeBytes(of: drand48()) { bytes in
            bytes.load(as: UInt64.self)
        }
    }
}

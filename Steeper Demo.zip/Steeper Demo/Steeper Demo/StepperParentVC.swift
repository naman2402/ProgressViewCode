//
//  StepperParentVC.swift
//  Steeper Demo
//
//  Created by Namaan.Agrawal on 11/08/21.
//

import Foundation
import UIKit

enum ControllerCurrentlyUsingFor {
    case textToPay
    case autoPay
    case makePayment
    case payBill
    case verifyAccount
    case paymentDetails
    case reviewConfirm
    case efficiency
  
}

class StepperParentVC: UIViewController {
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var stepView: ProgressView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var parentStepperView: UIView!
    var contentChildViewControllers: [UIViewController] = []
    var controllerUsingFor: ControllerCurrentlyUsingFor = .makePayment
    
    override func viewDidLoad() {
        //activeViewController = contentChildViewControllers.first
   //     stepView.lineWidth =  Utility.isIpad() ? AppSize.twelve : AppSize.eight
        //stepView.backgroundColor = UIColor.clear
      stepView.configureStepView(steps: contentChildViewControllers.count, selectedStep: 1)
       self.updateTitleLabel()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

     self.setNavigationTitle()
      //self.setNavigationBar(type: .default) { (_) in}
    }
    private func setNavigationTitle(){
        self.title = "Payment"
        /*switch self.controllerUsingFor {
        case .makePayment:
            self.title = "Payment"
        
        case .textToPay:
        self.title = "AutoPay"
        case .autoPay:
        self.title = "AutoPay"
        case .payBill:
        self.title = "PayBill"
        case .verifyAccount:
        self.title = "Verify Account"
        case .paymentDetails:
        self.title = "Payment Details"
        case .reviewConfirm:
        self.title = "Review Confirm"
        case .efficiency:
        self.title = "Efficiency"
    }*/
    }

    var activeViewController: UIViewController? {
       didSet {
           removeInactiveViewController(inactiveViewController: oldValue)
           updateActiveViewController()
       }
   }

    private func removeInactiveViewController(inactiveViewController: UIViewController?) {
        if let inActiveVC = inactiveViewController {
            // call before removing child view controller's view from hierarchy
            inActiveVC.willMove(toParent: nil)
            
            inActiveVC.view.removeFromSuperview()
            
            // call after removing child view controller's view from hierarchy
            inActiveVC.removeFromParent()
        }
    }
    
    private func updateActiveViewController() {
        if let activeVC = activeViewController {
            // call before adding child view controller's view as subview
            addChild(activeVC)
            
            activeVC.view.frame = containerView.bounds
            containerView.addSubview(activeVC.view)
            
            // call before adding child view controller's view as subview
            activeVC.didMove(toParent: self)
        }
    }
    
/*func setUpColor() {
        
    stepView.setStepperTheme(color: .black progressColor: .colors.button.primary, textColor: .colors.text.stepperText, progressTintColor: .colors.view.background)
        
    self.parentStepperView.backgroundColor = .blue
        self.titleLabel.type = .stepperTitle()
        
    } */
    
    private func updateTitleLabel(step: Int = 1) {
        var titleText: String = "Updated"
        
       switch self.controllerUsingFor {
        case .efficiency:
            titleText = "Enrollment details"
        case .verifyAccount:
             titleText = "Verified"
        case .reviewConfirm:
            titleText = "Reviewed"
        default:
            titleText = " Not able to find"
        }

        self.titleLabel.text = "All done"
    }

}





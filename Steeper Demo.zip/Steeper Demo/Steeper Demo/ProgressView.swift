//
//  ProgressView.swift
//  Steeper Demo
//
//  Created by Namaan.Agrawal on 09/08/21.
//
import Foundation
import CoreGraphics
import UIKit

class StepView : UIView {
    
    var numberOfSteps:Int = 1
    var selectedStep:Int = 1
    var color = UIColor(red: 179.0/255.0, green: 189.0/255.0, blue: 194.0/255.0, alpha: 1.0)
    var progressColor = UIColor(red: 0.0/255.0, green: 189.0/255.0, blue: 0.0/255.0, alpha: 0.0/255.0)
    var lineWidth: CGFloat = 2
    var textColor:UIColor = UIColor.black
    var progressTintColor = UIColor(red: 0.0/255.0, green: 180.0/255.0, blue: 124.0/255.0, alpha: 1.0)
    var margin = CGFloat(5.0)
    var radius = CGFloat(3.0)
    
    // Only override draw() if you perform custom drawing.
    override func draw(_ rect: CGRect) {
        
        if selectedStep >= 1 && numberOfSteps > 1 {
            
//            let height = bounds.height > 30 ? bounds.height : CGFloat(30)
            // get progress view rect
            let availableWidth = bounds.width - CGFloat(2 * margin)
            
            var x = margin
           
            //let diameter = height - margin
            let diameter = radius

            let circleY:CGFloat = 0
            let lineHeight = lineWidth
            
            let progressLineWidth = (availableWidth - (CGFloat(diameter) * CGFloat(numberOfSteps))) / CGFloat(numberOfSteps - 1)
            
            // Add complete progress line
            let lineY = (CGFloat(diameter) - CGFloat(lineWidth))/2
            
            let origin = CGPoint(x: x + diameter/2, y: lineY)
            let size = CGSize(width: availableWidth - CGFloat(diameter), height: lineHeight)
            addLine(rect: CGRect(origin: origin, size: size), color: color)
            
            if selectedStep > numberOfSteps {
                selectedStep = numberOfSteps
            }
            
            for idx in 1...numberOfSteps {
                
                if idx < selectedStep {
                    // Add line also, because for each completed step there will be next remaining step.
                    let origin = CGPoint(x: x + diameter/2, y: lineY)
                    let size = CGSize(width: progressLineWidth + CGFloat(diameter), height: lineHeight)
                    addLine(rect: CGRect(origin: origin, size: size), color: progressColor)
                    addCompletedStepCircle(origin: CGPoint(x: x, y: circleY), diameter: diameter)
                    
                    x += (diameter + progressLineWidth)
                } else if idx == selectedStep {
                    addCurrentStepCircle(origin: CGPoint(x: x, y: circleY), diameter: CGFloat(diameter))
                    x += (diameter + (progressLineWidth))
                } else {
                    // with text
                    addStepCircle(origin: CGPoint(x: x, y: circleY), diameter: (diameter), step: idx)
                    x += (diameter + (progressLineWidth))
                }
            }
        }
    }
    
    func addCurrentStepCircle(origin:CGPoint, diameter:CGFloat) {
        
        let circle = UIBezierPath(ovalIn: CGRect(origin: origin, size: CGSize(width: diameter, height: diameter)))
        progressColor.setFill()
        circle.fill()
        
        let innerOrigin = CGPoint(x: origin.x + diameter/4, y: origin.y + diameter/4)
        let innerCircle = UIBezierPath(ovalIn: CGRect(origin: innerOrigin, size: CGSize(width: diameter/2, height: diameter/2)))
        progressTintColor.setFill()
        innerCircle.fill()
    }
    
    func addCompletedStepCircle(origin:CGPoint, diameter:CGFloat) {
        progressColor.setFill()
        let rect = CGRect(origin: origin, size: CGSize(width: diameter, height: diameter))
        let circle = UIBezierPath(ovalIn: rect)
        circle.fill()
        
        // Add tick
        let checkmark = UIBezierPath()
        let tickStart = CGPoint(x: origin.x + diameter*0.25, y: origin.y + diameter*0.55)
        checkmark.move(to: tickStart)
        checkmark.addLine(to: CGPoint(x: origin.x + diameter*0.4, y: origin.y + diameter*0.7))
        checkmark.addLine(to: CGPoint(x: origin.x + diameter*0.65, y: origin.y + diameter*0.4))
        checkmark.lineCapStyle = CGLineCap.square
        
        progressTintColor.setStroke()
        checkmark.lineWidth = 3
        checkmark.stroke()
    }
    
    func addStepCircle(origin:CGPoint, diameter:CGFloat, step:Int) {
        color.setFill()
        let rect = CGRect(origin: origin, size: CGSize(width: diameter, height: diameter))
        let circle = UIBezierPath(ovalIn: rect)
        circle.fill()
        
        // text
        self.draw("\(step)", rect, UIFont.boldSystemFont(ofSize: diameter/3))
    }
    
    func draw(_ text: String, _ rect: CGRect, _ font: UIFont) {
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let attributes = [
            NSAttributedString.Key.paragraphStyle: paragraphStyle,
            //NSAttributedString.Key.font: AppFonts.regular.withSize(AppSize.fifteen),
            NSAttributedString.Key.foregroundColor: textColor
        ]
        //NSAttributedString(string: text, attributes: attributes).draw(in: rect.insetBy(dx: 0, dy: (rect.height - font.pointSize)/2))
        // TODOs: - Manage this with dynamic font and size
        NSAttributedString(string: text, attributes: attributes).draw(in: rect.insetBy(dx: 0, dy: (rect.height - font.pointSize)/7))

    }
    
    func addLine(rect:CGRect, color:UIColor) {
        color.setFill()
        let line = UIBezierPath(rect: rect)
        line.fill()
    }
}

@IBDesignable class ProgressView : UIView {

    func redraw() {
        self.stepsView.setNeedsDisplay()
    }
    @IBInspectable var numberOfSteps:Int = 1 {
        didSet {
            self.stepsView.numberOfSteps = numberOfSteps
        }
    }
    @IBInspectable var selectedStep:Int = 0 {
        didSet {
            self.stepsView.selectedStep = selectedStep
            redraw()
        }
    }
    
    private var _selectedStep:Int = 1
    
    @IBInspectable var color = UIColor(red: 179.0/255.0, green: 189.0/255.0, blue: 194.0/255.0, alpha: 1.0) {
        didSet {
            self.stepsView.color = color
            redraw()

        }
    }
    
    @IBInspectable var progressColor:UIColor = UIColor.blue {
        didSet {
            self.stepsView.progressColor = progressColor
            redraw()

        }
    }
    
    @IBInspectable var lineWidth: CGFloat = 2 {
        didSet {
            self.stepsView.lineWidth = lineWidth
            redraw()

        }
    }
    
    @IBInspectable var textColor:UIColor = UIColor.black {
        didSet {
            self.stepsView.textColor = textColor
            redraw()

        }
    }
    
    @IBInspectable var progressTintColor:UIColor = UIColor.white {
        didSet {
            self.stepsView.progressTintColor = progressTintColor
            redraw()

        }
    }
    
    override var backgroundColor: UIColor? {
        didSet {
            self.stepsView.backgroundColor = backgroundColor
            redraw()

        }
    }
    
    var titleLabel: UILabel  {
        let label = UILabel()
//        label.text = "Steps View"
        return label
    }
    
    var title:String {
        set {
            titleLabel.text = newValue
            redraw()

        }
        get {
            return titleLabel.text ?? ""
        }
    }
    
    var stepsView:StepView = {
        let view = StepView()
        
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }
    
    func commonInit() {
        // Add views
        self.addSubview(titleLabel)
        self.addSubview(stepsView)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        stepsView.translatesAutoresizingMaskIntoConstraints = false
        
        stepsView.margin = 0
        stepsView.backgroundColor = .red
        //set layout
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: self.topAnchor, constant: 0), titleLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: stepsView.margin)
        
        

        ])
            //constraint(equalTo: stepsView.heightAnchor, multiplier: 1)
            
     
        
        setStepperTheme()
    }
    
    /*
     color: for line color
     progressColor: outer circle color
     progresstintColor: inner circle color
     */
    func setStepperTheme(color:UIColor = .white, progressColor:UIColor = .blue, textColor:UIColor = .darkText, progressTintColor: UIColor = .white) {
        self.color = color
        self.progressColor = progressColor
        self.progressTintColor = progressTintColor
        self.textColor = textColor
        self.setNeedsDisplay()
    }
    
    // MARK: Configuration method
    func configureStepView(steps:Int, selectedStep:Int) {
        self.numberOfSteps = steps
        self.selectedStep = selectedStep
    }
} 
